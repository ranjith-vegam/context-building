import logging
from typing import List, Optional
import redis
from redis_stream.models import RedisStreamItem
from datetime import datetime


class RedisStream:
    #  r = redis.Redis(host="localhost", port=6375, decode_responses=True, password="Pass@123")
    def __init__(
        self,
        host="localhost",
        port=6379,
        password=None,
        stream_name: str = "test",
        consumer_group: str = "test_group",
        logger: logging.Logger = logging.getLogger(__name__),
    ):
        self.logger = logger
        self.logger.info(
            f"Initializing RedisStream with host={host}, port={port}, stream_name={stream_name}, consumer_group={consumer_group}"
        )
        try:
            self.redis = redis.Redis(
                host=host, port=port, decode_responses=True, password=password
            )
            self.stream_name = stream_name
            self.consumer_group = consumer_group
            self._create_group(stream_name, consumer_group)
            self.logger.info("RedisStream initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize RedisStream: {e}")
            raise

    def close(self):
        self.logger.info("Closing Redis connection")
        self.redis.close()

    def insert(self, entry: RedisStreamItem):
        self.logger.info(
            f"Inserting item into Redis stream: chat_id={entry.chat_id}, message_id={entry.message_id}"
        )
        try:
            result = self.redis.xadd(self.stream_name, entry.to_redis_dict())  # type: ignore
            self.logger.info(f"Item inserted successfully with msg_id={result}")
            return result
        except Exception as e:
            self.logger.error(f"Failed to insert item into Redis stream: {e}")
            raise

    def blocking_read(
        self,
        consumer_name: str,
        count: int,
        timeout: int = 0,  # in milliseconds
    ):
        self.logger.info(
            f"Starting blocking read: consumer={consumer_name}, count={count}, timeout={timeout}ms"
        )
        try:
            msgs = self.redis.xreadgroup(
                self.consumer_group,
                consumer_name,
                {self.stream_name: ">"},
                count=count,
                block=timeout,
            )
            response: List[RedisStreamItem] = []
            for stream, messages in msgs:  # type: ignore
                if stream != self.stream_name:
                    self.logger.warning(
                        f"Received message from unexpected stream: {stream}"
                    )
                    continue
                for msg_id, fields in messages:
                    response.append(RedisStreamItem.load_from_dict(fields, msg_id))
            self.logger.info(
                f"Blocking read completed: retrieved {len(response)} items"
            )
            return response
        except Exception as e:
            self.logger.error(f"Failed to perform blocking read: {e}")
            raise

    def _create_group(self, stream_name: str, group_name: str):
        self.logger.debug(
            f"Creating consumer group: stream={stream_name}, group={group_name}"
        )
        try:
            self.redis.xgroup_create(stream_name, group_name, mkstream=True)
            self.logger.info(
                f"Consumer group created: stream={stream_name}, group={group_name}"
            )
        except redis.ResponseError as e:
            if "BUSYGROUP" not in str(e):
                self.logger.error(f"Failed to create consumer group: {e}")
                raise e
            else:
                self.logger.info(
                    f"Consumer group already exists: stream={stream_name}, group={group_name}"
                )

    def make_as_done(self, msg_id: str):
        self.logger.info(f"Marking item as done: msg_id={msg_id}")
        try:
            result = self.redis.xack(self.stream_name, self.consumer_group, msg_id)
            self.logger.info(
                f"Item marked as done: msg_id={msg_id}, ack_count={result}"
            )
            return result
        except Exception as e:
            self.logger.error(
                f"Failed to mark item as done: msg_id={msg_id}, error={e}"
            )
            raise

    def get_failed_items(
        self,
        consumer_name: Optional[str] = None,
        count: int = 1,
        older_than: int = 10 * 60,  # in seconds default is 10 min
    ) -> List[RedisStreamItem]:
        """
        Get all pending items (items that have been read but not acknowledged).

        Args:
            consumer_name: Optional consumer name to filter pending items. If None, returns all pending items.
            count: Maximum number of pending items to return (default: 100)

        Returns:
            List of RedisStreamItem objects that are pending
        """
        self.logger.info(
            f"Getting failed items: consumer={consumer_name}, count={count}, older_than={older_than}s"
        )
        try:
            # Get pending message IDs
            if consumer_name:
                # Get pending items for a specific consumer
                self.logger.debug(
                    f"Fetching pending items for consumer: {consumer_name}"
                )
                pending = self.redis.xpending_range(
                    self.stream_name,
                    self.consumer_group,
                    min="-",
                    max="+",
                    count=count,
                    consumername=consumer_name,
                )
            else:
                # Get all pending items across all consumers
                self.logger.debug("Fetching all pending items across all consumers")
                pending = self.redis.xpending_range(
                    self.stream_name, self.consumer_group, min="-", max="+", count=count
                )

            # Extract message IDs from pending items
            msg_ids = [item["message_id"] for item in pending]  # type: ignore
            self.logger.debug(f"Found {len(msg_ids)} pending message IDs")

            if not msg_ids:
                self.logger.info("No pending items found")
                return []

            # Fetch the actual message data using XRANGE
            self.logger.debug(f"Fetching message data for {len(msg_ids)} pending items")
            messages = self.redis.xrange(
                self.stream_name, min=msg_ids[0], max=msg_ids[-1]
            )

            # Filter to only include the pending message IDs and convert to RedisStreamItem
            response: List[RedisStreamItem] = []
            pending_ids_set = set(msg_ids)
            for msg_id, fields in messages:  # type: ignore
                if msg_id in pending_ids_set:
                    response.append(RedisStreamItem.load_from_dict(fields, msg_id))

            self.logger.debug(
                f"Converted {len(response)} messages to RedisStreamItem objects"
            )

            # Filter items older than the specified duration
            cutoff_timestamp = int(datetime.now().timestamp()) - older_than
            initial_count = len(response)
            response = [item for item in response if item.created_at < cutoff_timestamp]
            filtered_count = initial_count - len(response)

            self.logger.info(
                f"Failed items retrieval completed: total_pending={len(msg_ids)}, "
                f"converted={initial_count}, filtered_out={filtered_count}, returned={len(response)}"
            )
            return response
        except Exception as e:
            self.logger.error(f"Failed to get failed items: {e}")
            raise


if __name__ == "__main__":
    r = RedisStream(host="192.168.1.49", port=6375, password="Pass@123")
    res = r.get_failed_items()
    print(res)
